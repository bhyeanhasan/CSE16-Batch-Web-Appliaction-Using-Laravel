<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Profile</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <link href="<?php echo e(asset("vendor/mdi-font/css/material-design-iconic-font.min.css")); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset("vendor/font-awesome-4.7/css/font-awesome.min.css")); ?>" rel="stylesheet" media="all">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
    <link href="<?php echo e(asset("vendor/select2/select2.min.css")); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset("vendor/datepicker/daterangepicker.css")); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset("vendor/main.css")); ?>" rel="stylesheet" media="all">

</head>

<body>
<div class="page-wrapper  p-t-100 p-b-100 font-robo" style="background-color: #F38C35">
    <div class="wrapper wrapper--w680">


        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="card card-1">

                <img id="cover" src="<?php echo e(asset($student->cover_pic)); ?>" style="height: 350px; width: 100%">

                <div class="card-body">

                        <div class="container">

                            <div class="row">

                                <div class="col-md-12 text-center">
                                    <img id="blah" src="<?php echo e(asset($student->profile_pic)); ?>" class="rounded-circle" style="height: 200px; width: 200px;margin-top: -150px">
                                </div>

                                <div class="col-md-12 mt-2">
                                    <h3 class="title text-center p-0 m-0"><?php echo e($student->name); ?></h3>
                                </div>

                                <div class="col-md-12 mb-4">
                                    <h4 style="text-align: center;"><i class="fa fa-comment-o" aria-hidden="true"></i> <?php echo e($student->bio); ?></h4>
                                </div>



                                <div class="col-md-12">

                                    <div class="divider running mb-3" style="height:5px;background-color:#1E8440;margin-bottom: 5px"></div>

                                    <h4 class="py-2"><i class="fa fa-id-badge" aria-hidden="true"></i> ID No				: <?php echo e($student->roll); ?></h4>
                                    <h4 class="py-2"><i class="fa fa-id-card-o" aria-hidden="true"></i> Registration No 	: <?php echo e($student->reg); ?></h4>
                                    <h4 class="py-2"><i class="fa fa-envelope-o" aria-hidden="true"></i> Email				: <?php echo e($student->email); ?></h4>
                                    <h4 class="py-2"><i class="fa fa-map-marker" aria-hidden="true"></i>Address 			: <?php echo e($student->address); ?> </h4>

                                    <?php if(auth()->guard()->guest()): ?>
                                        <h4 class="py-2"><i class="fa fa-volume-control-phone" aria-hidden="true"></i> Phone	: <span class="text-danger">Sorry You are not Loged In</span></h4>
                                    <?php else: ?>
                                        <h4 class="py-2"><i class="fa fa-volume-control-phone" aria-hidden="true"></i> Phone	: <?php echo e($student->phone); ?></h4>
                                    <?php endif; ?>

                                    <h4 class="py-2"><i class="fa fa-handshake-o" aria-hidden="true"></i> Blood Group		: <?php echo e($student->blood_group); ?>  </h4>
                                    <h4 class="py-2"><i class="fa fa-birthday-cake" aria-hidden="true"></i> Birth Day		: <?php echo e($student->birth_date); ?>  </h4>

                                    <div class="col-md-12 text-center my-3">
                                        <button type="button" class="btn btn-warning" ><a href="mailto:<?php echo e($student->email); ?>">Email Now</a></button>
                                    </div>

                                    <div class="divider running mt-3" style="height:5px;background-color:#1E8440;margin-bottom: 5px"></div>


                                    <div class="text-center">
                                        <h4>
                                            CSE 16 Batch <br>
                                            Patuakhali Science and Technology University
                                        </h4>
                                        <a href="/">Home</a>

                                    </div>

                                </div>




                            </div>

                        </div>

                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </div>
</div>

<script src="<?php echo e(asset("vendor/jquery/jquery.min.js")); ?>"></script>
<script src="<?php echo e(asset("vendor/select2/select2.min.js")); ?>"></script>
<script src="<?php echo e(asset("vendor/datepicker/moment.min.js")); ?>"></script>
<script src="<?php echo e(asset("vendor/datepicker/daterangepicker.js")); ?>"></script>
<script src="<?php echo e(asset("js/global.js")); ?>"></script>

</body>
</html>






























































<?php /**PATH C:\Users\NoYoN\Desktop\CSE16-Batch-Web-Appliaction-Using-Laravel\CSE16\resources\views/student/profile.blade.php ENDPATH**/ ?>