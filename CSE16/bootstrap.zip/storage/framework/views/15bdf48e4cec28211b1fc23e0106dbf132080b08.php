<?php echo e($slot); ?>

<?php /**PATH C:\Users\NoYoN\Desktop\CSE16-Batch-Web-Appliaction-Using-Laravel\CSE16\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>